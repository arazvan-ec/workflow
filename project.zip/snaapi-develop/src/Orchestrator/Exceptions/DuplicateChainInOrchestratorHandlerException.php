<?php

/**
 * @copyright
 */

namespace App\Orchestrator\Exceptions;

/**
 * @author Laura Gómez Cabero <lgomez@ext.elconfidencial.com>
 */
class DuplicateChainInOrchestratorHandlerException extends \Exception
{
}
